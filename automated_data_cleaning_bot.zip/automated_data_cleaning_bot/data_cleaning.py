import pandas as pd
import numpy as np
from scipy import stats
from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import LabelEncoder, MinMaxScaler, StandardScaler
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

from standardize_categories import standardize_categories  # Ensure this function is correctly implemented

# Download necessary NLTK data
nltk.download("stopwords")
nltk.download("wordnet")

def handle_missing_values(df, threshold=0.5, strategy="mean", steps=None):
    if steps is None:
        steps = []
        
    df = df.dropna(axis=1, thresh=int(threshold * len(df)))
    
    if strategy in ["mean", "median", "most_frequent"]:
        imputer = SimpleImputer(strategy=strategy)
    elif strategy == "knn":
        imputer = KNNImputer(n_neighbors=3)
    else:
        raise ValueError("Invalid strategy: Choose 'mean', 'median', 'most_frequent', or 'knn'")

    num_cols = df.select_dtypes(include=["number"]).columns
    df[num_cols] = imputer.fit_transform(df[num_cols])
    
    steps.append("Missing values handled")
    return df, steps

def remove_duplicates(df, steps=None):
    if steps is None:
        steps = []
        
    df = df.drop_duplicates()
    steps.append("Duplicates removed")
    return df, steps

def detect_outliers(df, method="iqr", contamination=0.05, z_thresh=3, steps=None):
    if steps is None:
        steps = []
        
    numeric_cols = df.select_dtypes(include=["number"]).columns  

    if method == "iqr":
        for col in numeric_cols:
            Q1, Q3 = df[col].quantile([0.25, 0.75])
            IQR = Q3 - Q1
            lower_bound, upper_bound = Q1 - 1.5 * IQR, Q3 + 1.5 * IQR
            initial_size = len(df)
            df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]
            steps.append(f"Outliers removed from '{col}' using IQR ({initial_size - len(df)} rows dropped)")
    
    elif method == "zscore":
        for col in numeric_cols:
            z_scores = np.abs(stats.zscore(df[col]))
            initial_size = len(df)
            df = df[z_scores < z_thresh]
            steps.append(f"Outliers removed from '{col}' using Z-score ({initial_size - len(df)} rows dropped)")

    elif method == "isolation_forest":
        iso_forest = IsolationForest(contamination=contamination, random_state=42)
        df["outlier"] = iso_forest.fit_predict(df[numeric_cols])
        initial_size = len(df)
        df = df[df["outlier"] == 1]  
        df.drop(columns=["outlier"], inplace=True)
        steps.append(f"Outliers removed using Isolation Forest ({initial_size - len(df)} rows dropped)")
    
    else:
        raise ValueError("Invalid method. Choose 'iqr', 'zscore', or 'isolation_forest'.")
    
    return df, steps

def encode_categorical_values(df, column, steps=None):
    if steps is None:
        steps = []
        
    if column in df.columns:
        encoder = LabelEncoder()
        df[column] = encoder.fit_transform(df[column].astype(str))
        steps.append(f"Categorical encoding applied to {column}")
    return df, steps

def scale_numeric_features(df, method="minmax", steps=None):
    if steps is None:
        steps = []
        
    scaler = MinMaxScaler() if method == "minmax" else StandardScaler()
    num_cols = df.select_dtypes(include=["number"]).columns
    df[num_cols] = scaler.fit_transform(df[num_cols])
    steps.append(f"Numeric features scaled using {method} scaling")
    return df, steps

def fix_date_formats(df, column, steps=None):
    if steps is None:
        steps = []
        
    if column in df.columns:
        df[column] = pd.to_datetime(df[column], errors="coerce")
        steps.append(f"Date format standardized for {column}")
    return df, steps

def clean_text(text):
    if pd.isna(text) or not isinstance(text, str):  # Handle NaN or non-string values
        return ""
    text = re.sub(r"[^a-zA-Z\s]", "", text.lower())
    stop_words = set(stopwords.words("english"))
    lemmatizer = WordNetLemmatizer()
    words = [lemmatizer.lemmatize(word) for word in text.split() if word not in stop_words]
    return " ".join(words)

def auto_clean_text_columns(df, steps=None):
    if steps is None:
        steps = []
        
    text_cols = df.select_dtypes(include=["object", "string"]).columns  

    if not text_cols.empty:
        df[text_cols] = df[text_cols].applymap(clean_text)
        steps.append(f"Text cleaned in columns: {', '.join(text_cols)}")

    return df, steps

def clean_data(df, outlier_method="iqr"):
    steps = []
    
    df, steps = handle_missing_values(df, steps=steps)
    df, steps = remove_duplicates(df, steps=steps)
    df, outlier_steps = detect_outliers(df, method=outlier_method, steps=steps)
    steps.extend(outlier_steps)  
    
    df, steps = standardize_categories(df, "City", ["New York", "San Francisco", "Los Angeles"], steps=steps)
    df, steps = encode_categorical_values(df, "Subscription Type", steps=steps)
    df, steps = scale_numeric_features(df, steps=steps)
    df, steps = fix_date_formats(df, "Joining Date", steps=steps)
    df, steps = auto_clean_text_columns(df, steps=steps)  # Auto-clean text columns
    
    return df, steps  
