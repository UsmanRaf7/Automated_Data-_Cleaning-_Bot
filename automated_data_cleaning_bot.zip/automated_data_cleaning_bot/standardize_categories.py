import pandas as pd
from fuzzywuzzy import process


def standardize_categories(df, column, reference_values, steps=[]):
    if column in df.columns:
        df[column] = df[column].apply(lambda x: process.extractOne(x, reference_values)[0] if pd.notna(x) else x)
        steps.append(f"Standardized categories in {column}")
    return df, steps