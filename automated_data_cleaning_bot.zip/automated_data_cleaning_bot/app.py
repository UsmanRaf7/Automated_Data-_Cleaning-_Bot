import os
import traceback
from flask import Flask, request, jsonify, send_file
import pandas as pd
from data_cleaning import clean_data  # Ensure correct import path!

# Initialize Flask App
app = Flask(__name__)

# Configure upload and cleaned folders
UPLOAD_FOLDER = "uploads"
CLEANED_FOLDER = "cleaned_files"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(CLEANED_FOLDER, exist_ok=True)

# ===========================
# 📌 Route: Home (Fix for 404 Error)
# ===========================
@app.route("/", methods=["GET"])
def home():
    return jsonify({"message": "Welcome to the Automated Data Cleaning API!"})

# ===========================
# 📌 Route: Upload & Clean Data
# ===========================
@app.route("/upload", methods=["POST"])
def upload_file():
    try:
        if "file" not in request.files:
            return jsonify({"error": "No file uploaded"}), 400

        file = request.files["file"]
        if file.filename == "":
            return jsonify({"error": "No file selected"}), 400

        if not file.filename.endswith(".csv"):
            return jsonify({"error": "Only CSV files are allowed"}), 400

        file_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(file_path)

        # Read CSV
        df = pd.read_csv(file_path, encoding="utf-8", encoding_errors="ignore")

        # Debugging: Print DataFrame Info
        print("📊 Original Dataframe Info:")
        print(df.info())

        # Clean Data (Unpacking Fix)
        cleaned_df, applied_steps = clean_data(df)  # ✅ FIXED

        # Save cleaned file
        cleaned_file_path = os.path.join(CLEANED_FOLDER, f"cleaned_{file.filename}")
        cleaned_df.to_csv(cleaned_file_path, index=False)

        return jsonify({
            "message": "File cleaned successfully!",
            "download_url": f"http://127.0.0.1:5000/download/{file.filename}",
            "applied_steps": applied_steps  # ✅ Optionally return applied steps
        })

    except Exception as e:
        print("\n🔥 ERROR OCCURRED 🔥")
        print(traceback.format_exc())  # Print full error stack trace
        return jsonify({"error": str(e)}), 500


# ===========================
# 📌 Route: Download Cleaned File
# ===========================
@app.route("/download/<filename>", methods=["GET"])
def download_file(filename):
    file_path = os.path.join(CLEANED_FOLDER, f"cleaned_{filename}")
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    return jsonify({"error": "File not found"}), 404

# ===========================
# 📌 Run Flask Server
# ===========================
if __name__ == "__main__":
    app.run(debug=True)
