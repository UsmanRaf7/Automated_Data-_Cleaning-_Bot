import streamlit as st
import requests
import pandas as pd
import os
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import IsolationForest

# Flask API URL (Change if hosted on a server)
FLASK_API_URL = "http://127.0.0.1:5000"

# ==============================
# 📌 Streamlit UI
# ==============================
st.set_page_config(page_title="Automated Data Cleaning Bot", layout="wide")

st.title("🧹 Automated Data Cleaning Bot")
st.write("Upload a messy CSV file, and get a cleaned version with applied transformations! 🚀")

# File Upload Section
uploaded_file = st.file_uploader("Upload your CSV file", type=["csv"])

if uploaded_file:
    st.success("✅ File uploaded successfully!")
    
    # Save the uploaded file temporarily
    file_path = os.path.join("uploads", uploaded_file.name)
    with open(file_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    # ==============================
    # 📌 Send File to Flask API
    # ==============================
    st.info("Cleaning data... Please wait!")
    with st.spinner("Processing..."):
        files = {"file": open(file_path, "rb")}
        response = requests.post(f"{FLASK_API_URL}/upload", files=files)
    
    if response.status_code == 200:
        result = response.json()
        download_url = f"{FLASK_API_URL}{result['download_url']}"
        applied_steps = result.get("applied_steps", [])  # Retrieve applied preprocessing steps
        
        # ==============================
        # 📌 Show Cleaned Data Preview
        # ==============================
        cleaned_file_path = os.path.join("cleaned_files", f"cleaned_{uploaded_file.name}")
        cleaned_df = pd.read_csv(cleaned_file_path)
        
        st.subheader("🔍 Cleaned Data Preview")
        st.dataframe(cleaned_df.head(10))
        
        # ==============================
        # 📌 Show Applied Preprocessing Steps
        # ==============================
        if applied_steps:
            st.subheader("📝 Applied Data Cleaning Steps")
            for step in applied_steps:
                st.write(f"- {step}")
        else:
            st.warning("⚠️ No preprocessing steps were applied!")

        # ==============================
        # 📌 Missing Values Heatmap
        # ==============================
        st.subheader("🌐 Missing Values Heatmap")
        plt.figure(figsize=(10, 5))
        sns.heatmap(cleaned_df.isnull(), cmap='viridis', cbar=False)
        st.pyplot(plt)

        # ==============================
        # 💀 Outlier Detection Graph
        # ==============================
        st.subheader("🔢 Outlier Detection Graphs")
        num_cols = cleaned_df.select_dtypes(include=['number']).columns
        if len(num_cols) > 0:
            selected_col = st.selectbox("Select column for outlier detection", num_cols)
            
            # Isolation Forest for Outlier Detection
            iso_forest = IsolationForest(contamination=0.05)
            outliers = iso_forest.fit_predict(cleaned_df[[selected_col]])
            cleaned_df['Outlier'] = outliers
            
            plt.figure(figsize=(8, 4))
            sns.boxplot(x=cleaned_df[selected_col], color='blue')
            sns.stripplot(x=cleaned_df[selected_col][cleaned_df['Outlier'] == -1], color='red', jitter=True)
            plt.title(f"Outlier Detection in {selected_col}")
            st.pyplot(plt)
        else:
            st.warning("No numeric columns available for outlier detection.")

        # ==============================
        # 📌 Download Button
        # ==============================
        st.success("✅ Data Cleaning Completed!")
        st.download_button(
            label="💽 Download Cleaned CSV",
            data=open(cleaned_file_path, "rb").read(),
            file_name=f"cleaned_{uploaded_file.name}",
            mime="text/csv"
        )
    else:
        st.error("❌ Error in data cleaning! Please try again.")
