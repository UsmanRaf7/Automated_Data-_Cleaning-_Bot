# __init__.py - Makes 'automated_data_cleaning_bot' a package

from .standardize_categories import standardize_categories
from .data_cleaning import (
    handle_missing_values,
    remove_duplicates,
    remove_outliers_iqr,
    remove_outliers_isolation_forest,
    encode_categorical_values,
    scale_numeric_features,
    fix_date_formats,
    clean_text,
    clean_data
)

__all__ = [
    "handle_missing_values",
    "remove_duplicates",
    "remove_outliers_iqr",
    "remove_outliers_isolation_forest",
    "standardize_categories",
    "encode_categorical_values",
    "scale_numeric_features",
    "fix_date_formats",
    "clean_text",
    "clean_data"
]